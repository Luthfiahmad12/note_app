<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$connection = new mysqli("localhost", "root", "", "crud-php");
$title      = $_POST['title'];
$content    = $_POST['content'];
// $date       = date('Y-m-d h:i:s');
$tz = 'Asia/Jakarta';
$dt = new DateTime("now", new DateTimeZone($tz));
$date = $dt->format('Y-m-d G:i:s');

$result = mysqli_query($connection, "insert into note_app set title='$title', content='$content', date='$date'");

if ($result) {
    echo json_encode([
        'message' => 'Data input successfully'
    ]);
} else {
    echo json_encode([
        'message' => 'Data Failed to input'
    ]);
}
