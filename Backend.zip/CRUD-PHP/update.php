<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$connection = new mysqli("localhost", "root", "", "crud-php");
$title      = $_POST['title'];
$content    = $_POST['content'];
$id         = $_POST['id'];

$result = mysqli_query($connection, "update note_app set title='$title', content='$content' where id='$id'");

if ($result) {
    echo json_encode([
        'message' => 'Data edit successfully'
    ]);
} else {
    echo json_encode([
        'message' => 'Data Failed to update'
    ]);
}
