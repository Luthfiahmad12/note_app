<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: *");

$connection = new mysqli("localhost", "root", "", "crud-php");
$data       = mysqli_query($connection, "select * from note_app");
$data       = mysqli_fetch_all($data, MYSQLI_ASSOC);

echo json_encode($data);
