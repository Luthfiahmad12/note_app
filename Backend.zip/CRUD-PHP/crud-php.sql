/*
 Navicat Premium Data Transfer

 Source Server         : Laragon
 Source Server Type    : MySQL
 Source Server Version : 50733
 Source Host           : localhost:3306
 Source Schema         : crud-php

 Target Server Type    : MySQL
 Target Server Version : 50733
 File Encoding         : 65001

 Date: 05/04/2023 22:55:47
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for note_app
-- ----------------------------
DROP TABLE IF EXISTS `note_app`;
CREATE TABLE `note_app`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `content` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of note_app
-- ----------------------------
INSERT INTO `note_app` VALUES (4, 'lorem ipsum sit', 'lorem ipsum dolor amet', '2023-04-05 22:10:35');
INSERT INTO `note_app` VALUES (5, 'judul', 'lorem ipsum dolor amet', '2023-04-05 22:24:15');

SET FOREIGN_KEY_CHECKS = 1;
