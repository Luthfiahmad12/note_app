<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$connection = new mysqli("localhost", "root", "", "crud-php");

$id = $_POST['id'];

$result = mysqli_query($connection, "delete from note_app where id=" . $id);

if ($result) {
    echo json_encode([
        'message' => 'Data delete successfully'
    ]);
} else {
    echo json_encode([
        'message' => 'Data Failed to delete'
    ]);
}
